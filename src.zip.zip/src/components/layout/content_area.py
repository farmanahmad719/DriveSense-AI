import customtkinter as ctk

from src.components.layout.camera_panel import CameraPanel
from src.components.layout.right_panel import RightPanel

from src.engine.detection_engine import DetectionEngine
from src.alerts.alarm import AlarmManager

class ContentArea(ctk.CTkFrame):

    def __init__(self, parent,dashboard):

        super().__init__(
            parent,
            fg_color="transparent"
        )
        self.dashboard = dashboard

        # ---------------- Layout ----------------

        self.grid_columnconfigure(0, weight=3)
        self.grid_columnconfigure(1, weight=7)

        self.grid_rowconfigure(0, weight=1)

        # ---------------- Camera ----------------

        self.camera = CameraPanel(self)

        self.camera.grid(
            row=0,
            column=0,
            sticky="nsew",
            padx=(0, 15)
        )

        # ---------------- Right Panel ----------------

        self.right = RightPanel(self)

        self.right.grid(
            row=0,
            column=1,
            sticky="nsew"
        )
        # ---------------- Backend ----------------

        self.engine = DetectionEngine()

        self.alarm = AlarmManager()

        self.engine.start(0)

        # Start live dashboard updates
        self.after(15, self.update_dashboard)
    def update_dashboard(self):

        ret, result = self.engine.process_frame()

        if ret:

            # Update camera
            self.camera.camera.update_frame(result.frame)

            self.camera.camera.set_connection(True)

            # Update dashboard UI
            self.right.update(result)

            # Alarm
            if result.is_drowsy or result.is_distracted:

                self.alarm.play_alarm()

            else:

                self.alarm.stop_alarm()

        else:

            self.camera.camera.set_connection(False)

        self.after(
            200,
            self.update_dashboard
        )    
        